If you get the following error message:

“FinalHE” is damaged and can’t be opened. You should move it to the Trash."

open terminal

enter the following command

xattr -cr {path where you extracted FinalHE app}

then run the app it should run fine

this app is built and tested on M1 mac with psvita 3.74

cheers.
